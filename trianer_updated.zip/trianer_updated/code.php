<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_student']))
{
    $student_id = mysqli_real_escape_string($con, $_POST['delete_student']);

    $query = "DELETE FROM trainer WHERE trainerId='$student_id' ";

    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Student Deleted Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Deleted";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['update_student']))
{
    $student_id = mysqli_real_escape_string($con, $_POST['student_id']);

    $name = mysqli_real_escape_string($con, $_POST['name']);
    // $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    // $dob = mysqli_real_escape_string($con, $_POST['dob']);  //dob

    $ic = mysqli_real_escape_string($con, $_POST['ic']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $birthday = mysqli_real_escape_string($con, $_POST['birthday']);
    $salary = mysqli_real_escape_string($con, $_POST['salary']);
    $planId = mysqli_real_escape_string($con, $_POST['plan']);
    $status = mysqli_real_escape_string($con, $_POST['status']);

    $query = "UPDATE trainer SET trainerName='$name', trainerEmail='$email', trainerPhone='$phone', trainerDOB='$birthday',trainerIC='$ic', trainerGender='$gender', planId='$planId', trainerStatus='$status' WHERE trainerId='$student_id' ";

    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Student Updated Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Updated";
        header("Location: index.php");
        exit(0);
    }

}


if(isset($_POST['save_student']))
{
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $dob = mysqli_real_escape_string($con, $_POST['dob']);  //dob

    $ic = mysqli_real_escape_string($con, $_POST['ic']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);

    $salary = mysqli_real_escape_string($con, $_POST['salary']);
    $planId = mysqli_real_escape_string($con, $_POST['plan']);
    $status = mysqli_real_escape_string($con, $_POST['status']);

    // $query = "INSERT INTO trainer (
    //     firstName,email,ic,lastName) VALUES ('$name','$email','$phone','$dob')";

    $query = "INSERT INTO trainer (
    trainerName,trainerEmail,trainerPhone,trainerDOB,trainerIC,trainerGender,trainerSalary,planId,trainerStatus) VALUES ('$name','$email','$phone','$dob','$ic','$gender','$salary','$planId','$status')";

    $query_run = mysqli_query($con, $query);


    // echo ("$name,$email,$gender,$status,$planId, $name',$email,$phone,$dob,$ic,'$gender,$salary,$planId,$status");

    if($query_run)
    {
        $_SESSION['message'] = "Trainer Created Successfully";
        header("Location: trainer-create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Trainer Not Created";
        header("Location: trainer-create.php");
        exit(0);
    }
}

?>