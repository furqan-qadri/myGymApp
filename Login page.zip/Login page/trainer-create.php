<?php
session_start();
?>
<?php 
require_once('Login2.php');
$query = "select * from plan";
$query2 = "select * from trainer";
$result2 = mysqli_query($con, $query2);
$result = mysqli_query($con,$query);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>trainer Create</title>
</head>
<body>
  
    <div class="container mt-5">

        <?php include('feedback.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Add trainer
                            <a href="index.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="code.php" method="POST">

                            <div class="mb-3">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control">
                            </div>


                            <div class="mb-3">
                                <label> Email</label>
                                <input type="email" name="email" class="form-control">
                            </div>


                            <div class="mb-3">
                                <label> Phone</label>
                                <input type="text" name="phone" class="form-control">
                            </div>


                            <div class="mb-3">
                                <label>Date of birth</label>
                                <input type="date" name="dob" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label> ic</label>
                                <input type="text" name="ic" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label> Gender</label>
                                <input type="text" name="gender" class="form-control">
                            </div>



                            <div class="mb-3">
                                <label> Salary (in RM) </label>
                                <input type="text" name="salary" class="form-control">
                            </div>

                            <!-- <div class="mb-3">
                                <label>Plan</label>
                                <input type="number" name="plan" class="form-control">
                            </div> -->

                            <div class="mb-3">
                                <label>Status</label>
                                <input type="text" name="status" class="form-control">
                            </div>

                            <div class="mb-3">
                            <select id="plan" name="plan">
				            <option value="">Select plan</option>
				            <?php 
					        while($rows = mysqli_fetch_assoc($result))
					        {
						    echo '<option value="'.$rows['planId'].'">'.$rows['planName'].'</option>';
					        }
				            ?>
			                </select>
                            </div>


                            <div class="mb-3">
                                <button type="submit" name="save_student" class="btn btn-primary">Save trainer</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>