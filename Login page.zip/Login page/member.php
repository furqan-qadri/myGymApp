<?php 
require_once('Login2.php');
$query = "select * from member";
$result = mysqli_query($con,$query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <title>Members page</title>
   <link rel="stylesheet" href="member.css">
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <!-- Bootstrap CSS  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
<div class="main">
    

    <ul class="nav">
    <img src="Logo.jpg" alt="HTML5 Icon" style="width:64px;height:64px;">
        <li><a href="/home">Dashboard</a></li>
        <li><a href="/home">Members</a></li>
        <li><a href="/blog">Trainers</a></li>
        <li><a href="/blog">Packages</a></li>
        <li><a href="/blog">Plans</a></li>
      </ul>

      <div class="sidebar">
        <a class="active" href="#home">Annoucement</a>
        <a href="#news">Repair report</a>
        <a href="#contact">New Equipment</a>
        <a href="#about">Payment notice</a>
      </div>
   

      <div class="container">
        <div class="row">
            <div class="col m-auto">
                <div class="card mt-5">
                    <table class="table table-bordered">
                        <tr>
                            <th> Member ID </th>
                            <th> Member Name </th>
                            <th> Member Email </th>
                            <th> Member status </th>

                        </tr>
                                <tr>
                                    <?php while ($rows = mysqli_fetch_assoc($result))
                                    {?>
                                        <td><?php echo $rows['memberId']?></td>
                                        <td><?php echo $rows['memberName']?></td>
                                        <td><?php echo $rows['memberEmail']?></td>
                                        <td><?php echo $rows['memberStatus']?></td>
                                    </tr>    
                                    <?php
                                    }
                                
                                    ?>
                                
                                
                                


                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</body>

</html>