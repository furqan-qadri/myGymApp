
<?php 
require_once('Login2.php');

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Trainer View</title>
</head>
<body>

    <div class="container mt-5">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Trainer View Details 
                            <a href="index.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {

                            

                            $student_id = mysqli_real_escape_string($con, $_GET['id']);



                            $query = "SELECT * FROM trainer WHERE trainerId='$student_id' ";

                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)


                                $student = mysqli_fetch_array($query_run);
                                // $student["trainerId"]
                               

                                // $query1 = "SELECT * FROM plan WHERE planId='$field1name';

                                // $result = mysqli_query($con,$query1);


                                ?>
                                
                                    <div class="mb-3">
                                        <label>Trainer Name</label>
                                        <p class="form-control">
                                            <?=$student['trainerName'];?>
                                        </p>
                                    </div>
                                    <div class="mb-3">
                                        <label> Email</label>
                                        <p class="form-control">
                                            <?=$student['trainerEmail'];?>
                                        </p>
                                    </div>
                                    <div class="mb-3">
                                        <label> Phone</label>
                                        <p class="form-control">
                                            <?=$student['trainerPhone'];?>
                                        </p>
                                    </div>
                                    <div class="mb-3">
                                        <label>Date of birth</label>
                                        <p class="form-control">
                                            <?=$student['trainerDOB'];?>
                                        </p>
                                    </div>

                                    <div class="mb-3">
                                        <label>IC/Passport</label>
                                        <p class="form-control">
                                            <?=$student['trainerIC'];?>
                                        </p>
                                    </div>

                                    <div class="mb-3">
                                        <label>Gender</label>
                                        <p class="form-control">
                                            <?=$student['trainerGender'];?>
                                        </p>
                                    </div>

                                    <div class="mb-3">
                                        <label>Plan</label>
                                        <p class="form-control">

                                            <!-- <?=$student['planId'];?> -->

                                            <?php 
 $field1name = $student["planId"];
//  echo $field1name;

$query1 = "SELECT * FROM plan WHERE planId='$field1name' ";

$result = mysqli_query($con,$query1);


					        $rows = mysqli_fetch_assoc($result);
                            
					        {
						    echo '<option value="'.$rows['planId'].'">'.$rows['planName'].'</option>';

                            // echo '<option value="'.$rows['planName'].'</option>';
					        }
				            ?>

                                        </p>
                                    </div>

                                    <div class="mb-3">
                                        <label>Status</label>
                                        <p class="form-control">
                                            <?=$student['trainerStatus'];?>
                                        </p>        
                                    </div>

                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>