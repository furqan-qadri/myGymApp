<?php
session_start();
require 'Login2.php';
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Student Edit</title>
</head>
<body>
  
    <div class="container mt-5">

        <?php include('feedback.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Member Update
                            <a href="memberBranch1.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            $member_id = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM member WHERE memberId='$member_id' ";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $member = mysqli_fetch_array($query_run);
                                ?>
                                <form action="CRUD.php" method="POST">
                                    <input type="hidden" name="member_id" value="<?= $member['memberId']; ?>">

                                    <div class="mb-3">
                                        <label>Member Name</label>
                                        <input type="text" name="name" value="<?=$member['memberName'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Member Email</label>
                                        <input type="email" name="email" value="<?=$member['memberEmail'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Member Phone</label>
                                        <input type="text" name="phone" value="<?=$member['memberPhone'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Member Status</label>
                                        <input type="text" name="Status" value="<?=$member['memberStatus'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Member IC</label>
                                        <input type="text" name="Ic" value="<?=$member['memberIc'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="update_member" class="btn btn-primary">
                                            Update member
                                        </button>
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>