<?php
require_once('Login2.php');

$query = 'SELECT member.memberId,plan.planId, plan.planCost, trainer.trainerId, trainer.trainerSalary, member.memberStatus
                            FROM member, plan, trainer
                            WHERE member.planId = plan.planId And member.trainerId = trainer.trainerId';
                            $query_run = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"  />

     <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .bg-container {
	background-image: url("dash_bg.jpg");
	width: 100%;

    /* width: max-content; */
    /* padding-top: 900px; */
	height: 100%;
	border: 1px solid white;
	box-sizing: border-box;
	background-size: cover;
	background-repeat: no-repeat;
	background-position: center center;
}
h1 {
	text-align: center;
}

        .button-logout{
            background-color: white;
            border-radius: 10px;
margin-left: 10px;
margin-top: 30px;
            width: 120px;
        }
        .navbar{
        /* display: flex; */
        /* height: 100px; */
        background-color: orange;
        padding-bottom: 20px;
        }

        body{
            margin:0;
        }

        .nv-1{
            /* display: inline-block; */
            display: grid;
            /* width: 200px; */
            /* flex-direction: column; */
            /* justify-content: space-around; */
            /* display: block; */
            grid-template-columns: 1fr 10fr 1fr;
            height: 110px;
            background-color: orange;
            text-align: center;
            vertical-align: center;

            margin-bottom:20px;

        }


        .nv-2{
            /* display: inline-block; */
            display: grid;
            /* width: 400px; */
            /* flex-direction: column; */
            /* justify-content: space-around; */
            /* display: block; */
            grid-template-columns: 1fr 1fr 1fr 1fr 1fr 1fr;
            column-gap: 100px;
            /* column-width: 120px; */
            height: 60px;
            margin-top:10px;
           
            /* background-color: aqua; */

        }

        .nv-1-1{
            /* border: 1px solid white; */
            padding-top:15px;
        }

        .nv-1-2{
            background-color:white;
            border-radius: white;
            color:black;
            /* border:1px solid black; */
            text-align: center;
            /* width: 300px; */
            border-radius: 12px;
            padding-top: 15px;
            padding-left:40px;
            padding-right:40px;
            /* font-size: 19px; */
        }


        .sidebar {
  background: #DB1F48;
  grid-area: sidebar;
  border-radius: var(--main-radius);
  padding-top: var(--main-padding);
  padding:10px;

}

.main {
  grid-area: main;
  border-radius: var(--main-radius);
  padding-top: var(--main-padding);
}

@media only screen and (max-width: 550px) {
  .container {
    grid-template-columns: 1fr;
    grid-template-rows: 2fr 0.4fr 1.2fr 1.2fr 2.2fr 1.2fr 1fr;
    grid-template-areas:
      "im"
      "title"
      "wel"
      "nav"
      "sidebar"
      "main"
  
  }
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
table.pepega{
   right:450px;
   top:400px;
   }

table.peepo{
   right:515px;
   top:200px;
   }
p.chat {
	background-color: white;
  text-align: left;
   }

   a{
    color:white;
   }

   .nav-icons{
    height:25px;
    margin-bottom: 5px;
   }

   .active{
    font-size: 25px;
    margin-left: 18px;
   }


    </style>
</head>
<body>

    <nav class="navbar">

        <div class="nv-1">

            <div class="nv-1-1">
                
                <img src="./Logo.jpg" style="width:110px;
                border-radius: 30px;" alt="">
            </div>
            <div class="nv-1-1" style="font-size: 50px; padding-top:15px;">
               Manego- Gym Management App
            </div>
            <div class="nv-1-1">
                <div class="button-logout">
                    <img src="./images_dash/door-svgrepo-com.svg" style="height:30px" alt="">
                    Log out
                </div>
               
            </div>

        </div>

        



        <div class="nv-2">
          
          <a  class="nv-1-2" href="">
              <div class="nv-1-2">
                  <img class="nav-icons" src="./images_dash/dashboard-svgrepo-com.svg" alt="">
  
                  Dashboard
              </div>
          </a>
              
          <a  class="nv-1-2" href="memberBranch1.php">
              <div class="nv-1-2">
                  <img class="nav-icons" src="./images_dash/person-team-svgrepo-com.svg" alt="">
  
                  Members
              </div>
          </a>

          <a  class="nv-1-2" href="index.php">
              <div class="nv-1-2">
                  <img class="nav-icons" src="./images_dash/strong-man-silhouette-with-weight-svgrepo-com.svg" alt="">
  
                  Trainers
              </div>
          </a>

          <a  class="nv-1-2" href="schedule\index.php">
              <div class="nv-1-2">
                  <img class="nav-icons" src="./images_dash/schedule-calendar-svgrepo-com.svg" alt="">
  
                  Schedule
              </div>
          </a>

          <a  class="nv-1-2" href="plan.php">
              <div class="nv-1-2">
                  <img class="nav-icons" src="./images_dash/failed-plan-svgrepo-com.svg" alt="">
  <br>
                    Plans 
              </div>
          </a>

          <a  class="nv-1-2" href="">
              <div class="nv-1-2">
                  <img class="nav-icons" src="./images_dash/person-team-svgrepo-com.svg" alt="">
  <br>My Profile
                  
              </div>
          </a>
         

          
          <!-- <div class="nv-1-2">
              <img class="nav-icons" src="./images_dash/person-team-svgrepo-com.svg" alt=""> <br>
           
                  Members
             
          </div>
          <div class="nv-1-2">
              <img class="nav-icons" src="./images_dash/strong-man-silhouette-with-weight-svgrepo-com.svg" alt=""> <br>
              Trainers
          </div>
          <div class="nv-1-2">
              <img class="nav-icons" src="./images_dash/schedule-calendar-svgrepo-com.svg" alt=""> <br>
              Schedule
          </div>
          <div class="nv-1-2">
              <img class="nav-icons" src="./images_dash/failed-plan-svgrepo-com.svg" alt=""> <br>
              Plans
          </div>
          <div class="nv-1-2">
              <img class="nav-icons" src="./images_dash/person-team-svgrepo-com.svg" alt=""> <br>
              MyProfile
          </div> -->

      </div>

    </nav>



<div style="display:flex; column-gap:0px;">

    <div class="sidebar">
    
    
      <a class="active" href="#home">Announcements</a>
      <!-- <br><br>
       
      Gym closed on 23-12-2022

      <br> <br>
      Trainer Nizam unavailable for three days 
      <br> -->

      <?php 
    
    
      $query = "SELECT * FROM announcement";
      $query_run = mysqli_query($con, $query);

      if(mysqli_num_rows($query_run) > 0)
      {
          foreach($query_run as $student)
          {
              ?>
              <tr>
                  <!-- <td><?= $student['id']; ?></td> -->
                  <!-- <td><?= $student['name']; ?></td>  -->

                  <a href="announce-view.php?id=<?= $student['id']; ?>" >

                  <td><?= $student['title']; ?></td>
                  <br> <br>

                  </a>

    
              </tr>
              
              <?php
          }
      }

    else
      { 
          echo "<h5> No Record Found </h5>";
      } 
   ?> 
      
      <!-- <a href="#news">Repair report<BR>22/4/2022</a> -->
      <!-- <a href="#news"><?= $student['email']; ?></a> -->
    
    
    
      <!-- <a href="#contact">New Equipment<BR>16/4/2022</a>
      <a href="#about">Payment notice<BR>14/4/2022</a>
      <a href="#about">Monthly Briefing<BR>05/4/2022</a> -->
      <!-- <a href="#about">Gym Anniversary<BR>05/4/2022</a>
      <a href="#about">Gym notice<BR>05/4/2022</a>
      <a href="#about">Annual Discount<BR>05/4/2022</a> -->
    
     
    </div>


    <!-- the report section -->


    <div
    class="bg-container rounded" 
   style="max-width:1600px;
   " >
   
       <div class="container p-3 my-3 border bg-white rounded-pill">
       
     <h1><i class="fa-solid fa-user"></i>  Total Members</h1>
     <h2 align="center">
       <?php $query = "SELECT *  FROM member";
           if ($result = mysqli_query($con, $query)) {
     
       // Return the number of rows in result set
       $rowcount = mysqli_num_rows( $result );
         
       // Display result
       printf($rowcount);
   }
        ?>
        </h2>
   </div>
   
   <div class="container p-3 my-3 bg-white text-black rounded-pill">
     <h1>  <i class="fa-solid fa-dumbbell"></i>  Total Trainers </h1>
     <h2 align="center"><?php $query = "SELECT *  FROM trainer";
           if ($result = mysqli_query($con, $query)) {
     
       // Return the number of rows in result set
       $rowcount = mysqli_num_rows( $result );
         
       // Display result
       printf($rowcount);
   }
        ?> </h2>
   </div>
   
   
   
   
   <div class="container p-3 my-3 bg-white text-black rounded-pill">
     <h1> <i class="fa-solid fa-person-walking"></i>    Number of Plans</h1>
     <h2 align="center"><?php $query = "SELECT *  FROM plan";
           if ($result = mysqli_query($con, $query)) {
     
       // Return the number of rows in result set
       $rowcount = mysqli_num_rows( $result );
         
       // Display result
       printf( $rowcount);
   }
        ?> 3</h2>
   </div>
   
   
   <div class="container p-3 my-3 bg-white text-black rounded-pill">
     <h1>   <i class="fa-solid fa-up-long"></i>   Profit</h1>
     <h2 align="center">
       
       <?php $query = "SELECT SUM(planCost)  FROM member, plan WHERE plan.planId = member.planId";
           if ($result = mysqli_query($con, $query)) {
     
       // Return the number of rows in result set
       $rowcount = mysqli_num_rows( $result );
       while($row = mysqli_fetch_array($result)){
           echo " Total profit: ". $row['SUM(planCost)'];
           echo "<br>";
    }
    // Display result
    //printf("Total rows in this table : %d\n", $rowcount);
}
     ?>
       
       </h2>
   </div>
   
   
   
   <div class="container p-3 my-3 bg-white text-black rounded-pill">
     <h1><i class="fa-solid fa-arrow-down-long"></i>   Expenses</h1>
     <h2 align="center"><?php $query = "SELECT  SUM(trainerSalary)  FROM trainer";
           if ($result = mysqli_query($con, $query)) {
     
       // Return the number of rows in result set
       $rowcount = mysqli_num_rows( $result );
       while($row = mysqli_fetch_array($result)){
           echo " Total cost: ". $row['SUM(trainerSalary)'];
           echo "<br>";
        }
        
    
        // Display result
        //printf("Total rows in this table : %d\n", $rowcount);
    }
         ?>
   </div>
   
   
   <!-- <div class="container p-3 my-3 bg-white text-black rounded-pill">
     <h1><i class="fa-solid fa-user"></i>    Total active members</h1>
     <h2 align="center"><?php $query = "SELECT  *  FROM member where memberStatus='Active'";
           if ($result = mysqli_query($con, $query)) {
     
       // Return the number of rows in result set
       $rowcount = mysqli_num_rows( $result );
       
       
   
       // Display result
       printf("Total rows in this table : %d\n", $rowcount);
   }
        ?></h2>
   </div> -->
   
   <div class="container p-3 my-3 bg-white text-black rounded-pill">
  <h1><i class="fa-solid fa-user"></i>    Total active members</h1>
  <h2 align="center"><?php $query = "SELECT  *  FROM member where memberStatus='Active'";
        if ($result = mysqli_query($con, $query)) {
  
    // Return the number of rows in result set
    $rowcount = mysqli_num_rows( $result );
    
    

    // Display result
    printf("Total rows in this table : %d\n", $rowcount);
}
     ?></h2>
</div>

<div class="container p-3 my-3 bg-white text-black rounded-pill">
  <h1><i class="fa-solid fa-user"></i>    Total Inactive members</h1>
  <h2 align="center"><?php $query = "SELECT  *  FROM member where memberStatus='Not Active'";
        if ($result = mysqli_query($con, $query)) {
  
    // Return the number of rows in result set
    $rowcount = mysqli_num_rows( $result );
    
    

    // Display result
    printf("Total rows in this table : %d\n", $rowcount);
}
     ?></h2>
</div>


   
   </div>
   



    
</body>
</html>