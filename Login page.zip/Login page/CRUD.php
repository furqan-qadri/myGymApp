<?php
session_start();
require 'Login2.php';

if(isset($_POST['delete_member']))
{
    $member_id = mysqli_real_escape_string($con, $_POST['delete_member']);

    $query = "DELETE FROM member WHERE memberId='$member_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Member Successfully removed";
        header("Location: memberBranch1.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Member Not Deleted";
        header("Location: memberBranch1.php");
        exit(0);
    }
}

if(isset($_POST['update_member']))
{
    $member_id = mysqli_real_escape_string($con, $_POST['member_id']);

    $memberName = mysqli_real_escape_string($con, $_POST['name']);
    $memberEmail = mysqli_real_escape_string($con, $_POST['email']);
    $memberPhone = mysqli_real_escape_string($con, $_POST['phone']);
    $memberStatus = mysqli_real_escape_string($con, $_POST['Status']);
    $Ic = mysqli_real_escape_string($con, $_POST['Ic']);

    $query = "UPDATE member SET memberName='$memberName', memberEmail='$memberEmail', memberPhone='$memberPhone', memberStatus='$memberStatus', memberIc='$Ic' WHERE memberId='$member_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Member Updated Successfully";
        header("Location: memberBranch1.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Memebr Not Updated";
        header("Location: memberBranch1.php");
        exit(0);
    }

}


if(isset($_POST['save_member']))
{
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $date = mysqli_real_escape_string($con, $_POST['date']);
    $status = mysqli_real_escape_string($con, $_POST['status']);
    $ic = mysqli_real_escape_string($con, $_POST['ic']);
    $plan = mysqli_real_escape_string($con, $_POST['plan']);
    $trainer = mysqli_real_escape_string($con, $_POST['trainer']);

    $query = "INSERT INTO member (memberName,memberEmail,memberPhone,memberDOB,memberStatus,memberIc,planId,trainerId) VALUES ('$name','$email','$phone','$date','$status','$ic','$plan','$trainer')";
    
    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Member Created Successfully";
        header("Location: create_member.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "member Not Created";
        header("Location: create-member.php");
        exit(0);
    }
}


if(isset($_POST['save_member']))
{
    $plan = mysqli_real_escape_string($con, $_POST['plan']);
    $query = "INSERT INTO plan (planName) VALUES ('$plan')";
    if($query_run)
    {
        $_SESSION['message'] = "Member Created Successfully";
        header("Location: create_member.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "member Not Created";
        header("Location: create-member.php");
        exit(0);
    }
}
?>