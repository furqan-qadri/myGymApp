<?php 
require_once('Login2.php');
$query = "select * from member";
$result = mysqli_query($con,$query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <title>Members page</title>
   
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <!-- Bootstrap CSS  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
   
</head>

<body>
<div class="main mt-4">
<?php include('feedback.php'); ?>  

    <ul class="nav">
    <img src="Logo.jpg" alt="HTML5 Icon" style="width:64px;height:64px;">
        <li><a href="/home">Dashboard</a></li>
        <li><a href="/home">Members</a></li>
        <li><a href="/blog">Trainers</a></li>
        <li><a href="/blog">Packages</a></li>
        <li><a href="plan.php">Plans</a></li>
      </ul>


      <div class="main_content mt-3">
        <?php include('feedback.php'); ?>
      <div class="row">
            <div class="col-md-12">
                <div class="card">
                <div class="card-header">
                        <h4>Members Details
                            <a href="create_member.php" class="btn btn-primary float-end">Add Member</a>
                            <a href="activeMembers.php" class="btn btn-primary float-end">Active Members</a>
                        </h4>
                    </div>
                    
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th> Member ID </th>
                            <th> Member Name </th>
                            <th> Member Email </th>
                            <th> Member status </th>
                            <th> Operation </th>

                        </tr>
                                <tr>
                                    <?php while ($rows = mysqli_fetch_assoc($result))
                                    {?>
                                        <td><?php echo $rows['memberId']?></td>
                                        <td><?php echo $rows['memberName']?></td>
                                        <td><?php echo $rows['memberEmail']?></td>
                                        <td><?php echo $rows['memberStatus']?></td>
                                        <td>
                                                    <a href="view_member.php?id=<?= $rows['memberId']; ?>" class="btn btn-info btn-sm">View</a>
                                                    <a href="update_member.php?id=<?= $rows['memberId']; ?>" class="btn btn-success btn-sm">Update</a>
                                                    <form action="CRUD.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete_member" value="<?=$rows['memberId'];?>" class="btn btn-danger btn-sm">Delete</button>
                                                    </form>
                                       </td>
                                    </tr>    
                                    <?php
                                    }
                                
                                    ?>
                                
                                
                                


                    </table>
                </div>
            </div>
        </div> 
    </div>

</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>