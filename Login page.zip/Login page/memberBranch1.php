<?php 
require_once('Login2.php');
$query = "select * from member";
$result = mysqli_query($con,$query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <title>Members page</title>
   
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <!-- Bootstrap CSS  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
   
</head>

<body>
<div class="main mt-4">
<?php include('feedback.php'); ?>  

<nav class="navbar navbar-expand-lg navbar-light bg-light">

<div >
    <a class="navbar-brand" href="#">
      <img src="Logo.jpg" height="80" alt="Logo"
        loading="lazy" />
    </a>
  </div>

  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="dashboard_14thjan.php">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="memberBranch1.php">Members</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="plan.php">Plans</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php">Trainers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ReportDashboard.php">Report</a>
        </li>
      </ul>
    </div>
  </div>
</nav>


      <div class="main_content mt-3">
        <?php include('feedback.php'); ?>
      <div class="row">
            <div class="col-md-12">
                <div class="card">
                <div class="card-header">
                        <h4>Members Details
                            <a  href="create_member.php" class="btn btn-primary float-end">Add Member</a>
                            
                            <a  style="margin-right:50px; background-color: green;" href="activeMembers.php" class="btn btn-primary float-end">Active Members</a>
                        </h4>
                    </div>
                    
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th> Member ID </th>
                            <th> Member Name </th>
                            <th> Member Email </th>
                            <th> Member status </th>
                            <th> Operation </th>

                        </tr>
                                <tr>
                                    <?php while ($rows = mysqli_fetch_assoc($result))
                                    {?>
                                        <td><?php echo $rows['memberId']?></td>
                                        <td><?php echo $rows['memberName']?></td>
                                        <td><?php echo $rows['memberEmail']?></td>
                                        <td><?php echo $rows['memberStatus']?></td>
                                        <td>
                                                    <a href="view_member.php?id=<?= $rows['memberId']; ?>" class="btn btn-info btn-sm">View</a>
                                                    <a href="update_member.php?id=<?= $rows['memberId']; ?>" class="btn btn-success btn-sm">Update</a>
                                                    <form action="CRUD.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete_member" value="<?=$rows['memberId'];?>" class="btn btn-danger btn-sm">Delete</button>
                                                    </form>
                                       </td>
                                    </tr>    
                                    <?php
                                    }
                                
                                    ?>
                                
                                
                                


                    </table>
                </div>
            </div>
        </div> 
    </div>

</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<footer class="bg-light text-center text-lg-start">
  <!-- Grid container -->
  <div class="container p-4">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <h5 class="text-uppercase">My Gym</h5>

        <p>
        By educating, motivating, and offering the most effective workout programme and nutrition lifestyle system ever developed, My Gym Fitness will significantly improve the quality of life for thousands of Malaysians. While pursuing their passions and serving their clients, our employees will change lives and have many possibilities for growth.
        </p>

      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <h5 class="text-uppercase">Contacts</h5>
        <h5>Alhadi@graduate.utm.my</h5>
        <h5>+601137122623</h5>
</body>

</html>