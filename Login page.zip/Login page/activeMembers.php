<?php
require_once('Login2.php');

$query = 'SELECT member.memberId,member.memberName, member.memberStatus, plan.planName, plan.planCost, trainer.trainerName
                            FROM member, plan, trainer
                            WHERE member.planId = plan.planId And member.trainerId = trainer.trainerId And member.memberStatus="Active"';
                            $query_run = mysqli_query($con, $query);
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Active Memebr View</title>
</head>
<body>
    
<nav class="navbar navbar-expand-lg navbar-light bg-light">

<div >
    <a class="navbar-brand" href="#">
      <img src="Logo.jpg" height="80" alt="Logo"
        loading="lazy" />
    </a>
  </div>

  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="dashboard.html">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="memberBranch1.php">Members</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="plan.php">Plans</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Trainers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ReportDashboard.php">Report</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
    <div class="container mt-5">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Active Memebrs 
                            <a href="memberBranch1.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <table class="table table-bordered table-striped">
                        <tr>
                            <th> Member ID </th>
                            <th> Member Name </th>
                            <th> Member status </th>
                            <th> Member plan </th>
                            <th> Plan cost </th>
                            <th> Member trainer </th>

                        </tr>
                                <tr>
                                    <?php while ($rows = mysqli_fetch_assoc($query_run))
                                    {?>
                                        <td><?php echo $rows['memberId']?></td>
                                        <td><?php echo $rows['memberName']?></td>
                                        <td><?php echo $rows['memberStatus']?></td>
                                        <td><?php echo $rows['planName']?></td>
                                        <td><?php echo $rows['planCost']?></td>
                                        <td><?php echo $rows['trainerName']?></td>
                                        
                                    </tr>    
                                    <?php
                                    }
                                
                                    ?>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <footer class="bg-light text-center text-lg-start">
  <!-- Grid container -->
  <div class="container p-4">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <h5 class="text-uppercase">My Gym</h5>

        <p>
        By educating, motivating, and offering the most effective workout programme and nutrition lifestyle system ever developed, My Gym Fitness will significantly improve the quality of life for thousands of Malaysians. While pursuing their passions and serving their clients, our employees will change lives and have many possibilities for growth.
        </p>

      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <h5 class="text-uppercase">Contacts</h5>
        <h5>Alhadi@graduate.utm.my</h5>
        <h5>+601137122623</h5>
</body>
</html>