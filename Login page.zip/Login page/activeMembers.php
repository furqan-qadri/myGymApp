<?php
require_once('Login2.php');

$query = 'SELECT member.memberId,member.memberName, member.memberStatus, plan.planName, plan.planCost, trainer.trainerName
                            FROM member, plan, trainer
                            WHERE member.planId = plan.planId And member.trainerId = trainer.trainerId And member.memberStatus="Active"';
                            $query_run = mysqli_query($con, $query);
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Active Memebr View</title>
</head>
<body>

    <div class="container mt-5">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Active Memebrs 
                            <a href="memberBranch1.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <table class="table table-bordered table-striped">
                        <tr>
                            <th> Member ID </th>
                            <th> Member Name </th>
                            <th> Member status </th>
                            <th> Member plan </th>
                            <th> Plan cost </th>
                            <th> Member trainer </th>

                        </tr>
                                <tr>
                                    <?php while ($rows = mysqli_fetch_assoc($query_run))
                                    {?>
                                        <td><?php echo $rows['memberId']?></td>
                                        <td><?php echo $rows['memberName']?></td>
                                        <td><?php echo $rows['memberStatus']?></td>
                                        <td><?php echo $rows['planName']?></td>
                                        <td><?php echo $rows['planCost']?></td>
                                        <td><?php echo $rows['trainerName']?></td>
                                        
                                    </tr>    
                                    <?php
                                    }
                                
                                    ?>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>