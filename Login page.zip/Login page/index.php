<?php
    session_start();
    require 'Login2.php';
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Trainer Home</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">

<div >
    <a class="navbar-brand" href="#">
      <img src="Logo.jpg" height="80" alt="Logo"
        loading="lazy" />
    </a>
  </div>

  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="dashboard_14thjan.php">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="memberBranch1.php">Members</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="plan.php">Plans</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Trainers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ReportDashboard.php">Report</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container mt-4">

        <?php include('feedback.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Trainer Details

                        

                            <a href="trainer-create.php" class="btn btn-primary float-end">Add trainers</a>

                            <a style="margin-right:50px; background-color:green;" href="active-trainers.php" class="btn btn-primary float-end">Active Trainers</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>

                                    <th>Phone</th>
                                    <th>Date of Birth</th>
                                    <th>IC</th>

                                    <th>Gender</th>
                                    <th>Plan</th>
                                    <!-- <th>Status</th> -->

                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>


                                <?php 

                                    $query = "SELECT * FROM trainer";
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $student)
                                        {
                                            ?>
                                            <tr>
                                                <td><?= $student['trainerId']; ?></td>
                                                <td><?= $student['trainerName']; ?></td>
                                                <td><?= $student['trainerEmail']; ?></td>
                                                <td><?= $student['trainerPhone']; ?></td>


                                                <td><?= $student['trainerDOB']; ?></td>

                                                <td><?= $student['trainerIC']; ?></td>

                                                <td><?= $student['trainerGender']; ?></td>

                                                <td><?= $student['planId']; ?></td>

                                                <!-- <td><?= $student['status']; ?></td> -->



                                                <td>
                                                    <a href="trainer-view.php?id=<?= $student['trainerId']; ?>" class="btn btn-info btn-sm">View</a>
                                                    <a href="trainer-edit.php?id=<?= $student['trainerId']; ?>" class="btn btn-success btn-sm">Edit</a>
                                                    <form action="code.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete_student" value="<?=$student['trainerId'];?>" class="btn btn-danger btn-sm">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>

                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> No Record Found </h5>";
                                    }
                                ?>
                                
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <footer class="bg-light text-center text-lg-start">
  <!-- Grid container -->
  <div class="container p-4">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <h5 class="text-uppercase">My Gym</h5>

        <p>
        By educating, motivating, and offering the most effective workout programme and nutrition lifestyle system ever developed, My Gym Fitness will significantly improve the quality of life for thousands of Malaysians. While pursuing their passions and serving their clients, our employees will change lives and have many possibilities for growth.
        </p>

      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <h5 class="text-uppercase">Contacts</h5>
        <h5>Alhadi@graduate.utm.my</h5>
        <h5>+601137122623</h5>
</body>
</html>